//
//  ViewController.swift
//  LeticiaEto_tableView
//
//  Created by COTEMIG on 24/06/25.
//

import UIKit
struct ColorData{
    let nome: String
    let cor: UIColor
}

class ViewController: UIViewController, UITableViewDataSource {
    let colorList : [ColorData]=[
        ColorData(nome: "Amarelo", cor: .yellow),
        ColorData(nome: "Laranja", cor: .orange ),
        ColorData(nome: "Roxo", cor: .purple),
        ColorData(nome: "Verde", cor: .green)
    ]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return colorList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier:"colorCell") as? ColorTableViewCell else{
            fatalError("Nao foi encontrad")
        }
        cell.configure(colorData: colorList[indexPath.item])
        return cell
    }
    
    
   
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        
    }


}

