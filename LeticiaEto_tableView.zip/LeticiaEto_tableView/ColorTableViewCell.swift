//
//  ColorTableViewCell.swift
//  LeticiaEto_tableView
//
//  Created by COTEMIG on 24/06/25.
//

import UIKit

class ColorTableViewCell: UITableViewCell {

    @IBOutlet weak var satckView: UIStackView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure (colorData: ColorData)-> Void
    {
        self.backgroundColor = colorData.cor
        let label = UILabel()
        label.text = colorData.nome
        satckView.addArrangedSubview(label)
    }

}
